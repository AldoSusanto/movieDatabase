package com.example.moviedatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements ListFragment.listListener {

    private movieDbApi movieDbApi;
    private List<Movie> movieList;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Calls the API, get and parse the JSON Object, then fill out the list of movies (var: movieList)
        getResponse();

    }



    public void getResponse(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.themoviedb.org/3/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        movieDbApi = retrofit.create(movieDbApi.class);

        Call<MovieList> call = movieDbApi.getMovieList();

        call.enqueue(new Callback<MovieList>() {
            @Override
            public void onResponse(Call<MovieList> call, Response<MovieList> response) {
                if(response.isSuccessful()){
                    if(response.body() != null){
                        Log.d("asd", "onResponse success !");
                        MovieList temp = response.body();
                        movieList = temp.getMovieList();

                        //Based on the movieList variable, displays the data presented to the textView
                        //activateFragment();
                        activateViewPager();

                    }
                }else{
                    Log.d("asd", "Code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<MovieList> call, Throwable t) {
                Log.d("asd", "onFailure is called");
                Log.d("asd", t.getMessage());
            }
        });

    }

    private void activateViewPager(){
        viewPager = findViewById(R.id.viewPager);
        adapter = new ViewPagerAdapter(getSupportFragmentManager(), movieList);
        viewPager.setAdapter(adapter);
    }

    //Sets the movie List fragment to the mainActivity
    private void activateFragment() {
        // Start activating the fragment
        //1. Create listFragment class
        //2. Create FragmentManager
        //3. Create FragmentTransaction based on FragmentManager
        //4. Using the fragmentTransaction object, we connect the id of layout
        //   with the listFragment object that we have
        //5. Commit the transaction

        //0.5 Check whether a fragment already existed or not. If already exist, then we don't create another fragment
        ListFragment savedFragment = (ListFragment) getSupportFragmentManager().findFragmentById(R.id.placeHolder);
        if(savedFragment == null){
            // Start activating the fragment
            ListFragment listFragment = new ListFragment(movieList);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            fragmentTransaction.add(R.id.placeHolder, listFragment);
            fragmentTransaction.commit();
            Log.d("asd", "List Fragment displayed");
        }

    }

    @Override
    public void onListSelected(int index) {

    }
}
